import json
from service.DBInit import DB
from models.get_flight import Flight
from service.custom_exception import Error
from uuid import UUID
from sqlalchemy.exc import NoResultFound

"""
 # @Python program 
 # @Author: Vaibhav. M
 # @Name: get-author.py
 # @Lambda name: lambda_get_author_mv
 # @Since: December 2022
 # @Version: 1.0
 # @See: Program to get author details from DB
"""
""" 
    Title:
        Lambda Handler method just gets the author details from db.
"""

def lambda_handler(event,context):
    try:
        connection = DB()
        Session = connection.connect()
        session = Session()
        journey_from = event['params']['querystring']['from']
        journey_to = event['params']['querystring']['to']
        journey_date = event['params']['querystring']['date']
        time_from = event['params']['querystring']['time_from']
        time_to = event['params']['querystring']['time_to']
        flight_data = session.query(Flight).filter(Flight.journey_from == journey_from and Flight.journey_to == journey_to and Flight.date == journey_date and (Flight.departure_time[11:16] >= time_from and Flight.departure_time[11:16] <= time_to)).all()
        for data in flight_data:
            response = {
                "flightNumber": str(data.get('flight_num','')),
                "flightName": str(data.get('flight_nanme','')),
                "dateOfJourney": str(data.get('date','')),
                "From": str(data.get('journey_from','')),
                "To": str(data.get('journey_to','')),
                "departureTime": str(data.get('departure_time',''))[11:16],
                "arrivalTime": str(data.get('arrival_time',''))[11:16]
                }
            return response
        else:
            raise NoResultFound('flight not found')
        
    except NoResultFound:
        error_response = {
            "message" : "flight not found"
        }
        error = json.dumps(error_response)
        raise Error(error)
        
    except KeyError as error:
        error_response = {
            "error" : "Invalid request",
            "errorMessage" : str(error)
        }
        error_message = json.dumps(error_response)
        raise Error(error_message)

    except ValueError:
        error_response = {
            "error" : "Invalid request",
            "errorMessage" : "Missing / Wrong details"
        }
        error_message = json.dumps(error_response)
        raise Error(error_message)

    except Exception as error:
        error_response = {
            "error" : "Internal server error",
            "errorMessage" : str(error)
        }
        error_message = json.dumps(error_response)
        raise Error(error_message)

    finally:
        session.close()
    