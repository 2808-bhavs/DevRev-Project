import json
from service.DBInit import DB
from models.authors import Authors
from models.address import address
from models.country import country
from service.custom_exception import Error
from uuid import UUID
from sqlalchemy.exc import NoResultFound

"""
 # @Python program 
 # @Author: Vaibhav. M
 # @Name: get-author.py
 # @Lambda name: lambda_get_author_mv
 # @Since: December 2022
 # @Version: 1.0
 # @See: Program to get author details from DB
"""
""" 
    Title:
        Lambda Handler method just gets the author details from db.
"""

def lambda_handler(event,context):
    try:
        connection = DB()
        Session = connection.connect()
        session = Session()
        authorid = event['params']['querystring']['authorId']
        UUID(authorid)
        author_data = session.query(Authors,address,country)\
            .join(address,address.address_id == Authors.address_id)\
            .join(country,country.country_uuid == address.country_uuid)\
            .filter(Authors.author_id == authorid).all()
        for data in author_data:
            response = {
                "authorId": str(authorid),
                "address":{
                    "addressId": str(data[0].address_id),
                    "doorNo": str(data[1].door_no),
                    "addressLine1": str(data[1].address_line_1),
                    "addressLine2": str(data[1].address_line_2),
                    "place": str(data[1].place),
                    "city": str(data[1].city),
                    "zipcode": str(data[1].zipcode),
                    "latitude": str(data[1].latitude),
                    "longitude": str(data[1].longitude),
                    "countryCodeUuid": str(data[1].country_uuid),
                    "countryCode": str(data[2].country_code),
                    "countryName": str(data[2].country_name),
                    "otherDetails": data[1].other_details
                },
                "authorName": str(data[0].author_name),
                "authorAge": data[0].author_age,
                "authorRating": data[0].author_rating,
                "qualification": data[0].qualification,
                "specialist": data[0].specialist,
                "status": str(data[0].status),
                "createdBy":str(data[0].created_by),
                "createdOn":str(data[0].created_on),
                "updatedBy":str(data[0].updated_by),
                "updatedOn":str(data[0].updated_on)
            }
            return response
        else:
            raise NoResultFound('Author not found')
        
    except NoResultFound:
        error_response = {
            "message" : "Author not found"
        }
        error = json.dumps(error_response)
        raise Error(error)
        
    except KeyError as error:
        error_response = {
            "error" : "Invalid request",
            "errorMessage" : str(error)
        }
        error_message = json.dumps(error_response)
        raise Error(error_message)

    except ValueError:
        error_response = {
            "error" : "Invalid request",
            "errorMessage" : "Missing / Wrong details in column[authorId]"
        }
        error_message = json.dumps(error_response)
        raise Error(error_message)

    except Exception as error:
        error_response = {
            "error" : "Internal server error",
            "errorMessage" : str(error)
        }
        error_message = json.dumps(error_response)
        raise Error(error_message)

    finally:
        session.close()
    