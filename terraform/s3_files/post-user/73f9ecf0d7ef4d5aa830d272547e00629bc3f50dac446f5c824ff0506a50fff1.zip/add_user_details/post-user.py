# # POST BOOK LAMBDA CODE
# import json,sys,re
# from sqlalchemy import exc
# from service.custom_exception import Error
# from service.DBInit import DB
# from models.get_book import GetBook

# """
#  # @Python program 
#  # @Author: Singareddy Maneesh
#  # @Name: book-lambda.py
#  # @Lambda name:book-lambda-maneesh
#  # @See: Program to insert new book data in books table 
# """
# """ 
#     Title:
#         Lambda Handler method to insert/post  book data to the Database .
# """

# def lambda_handler(event,context):
#     try:
#         request_body = event["body-json"]
#         request_body["modifiedBy"]=request_body["createdBy"]
#         connection = DB()
#         Session = connection.connect()
#         session = Session()
#         no_need = True
#         if not request_body:
#             raise ValueError("Validation error, Missing body")
#         if(len(event["params"]["querystring"])!=0):
#             no_need =False
#             raise ValueError("parameters not required")
#         error_columns = []        
#         if("bookName" not in request_body):
#             error_columns.append("bookName")
#         if("dateOfPublication" not in request_body):
#             error_columns.append("dateOfPublication")
#         if("publisherName" not in request_body):
#             error_columns.append("publisherName")
#         if("status" not in request_body):
#             error_columns.append("status")
#         if("otherDetails" not in request_body):
#             error_columns.append("otherDetails") 
#         if("authorId" not in request_body):
#             error_columns.append("authorId")
#         if("categoryId" not in request_body):
#             error_columns.append("categoryId") 
#         if("createdBy" not in request_body):
#             error_columns.append("createdBy")
#         if(len(error_columns)!=0):
#             raise TypeError("Missing required fields")
#         bookname = request_body["bookName"]
#         dateofpublication = request_body["dateOfPublication"]
#         publishername = request_body["publisherName"]
#         status = request_body["status"]
#         otherdetails = request_body["otherDetails"]
#         createdby = request_body["createdBy"]
#         if(bookname.strip()=="" or bookname ==None or not(re.match('[a-zA-Z\s]+$',bookname)) or len(bookname)>60):
#             error_columns.append("bookName")
#         if(publishername.strip()=="" or publishername ==None or not(re.match('[a-zA-Z\s]+$',publishername)) or len(publishername)>200):
#             error_columns.append("publisherName")
#         if(status.strip()=="" or status ==None or not(re.match('[a-zA-Z\s]+$',status)) or len(status)>1):
#             error_columns.append("status")
#         if(otherdetails=="" or otherdetails==None):
#             error_columns.append("otherDetails")
#         if(createdby.strip()=="" or createdby==None or not(re.match('[a-zA-Z\s]+$',createdby)) or len(createdby)>60):
#             error_columns.append("createdBy")
#         date=list(dateofpublication.split("-"))
#         if(len(date)!=3):
#             error_columns.append("dateOfPublication")
#             raise TypeError("Required fields are Missing/Empty")
#         day,month,year=date[0],date[1],date[2]
#         if(int(month)>12 or int(month)<1 or int(day)>31 or int(day)<1):
#             error_columns.append("dateOfPublication")
#         if len(error_columns) != 0:
#             raise TypeError("Required fields are Missing/Empty")
#         else:
#             post_data = GetBook()
#             post_data.get_book_request(request_body)
#             session.add(post_data)
#             session.flush()
#             session.commit()
#             book_result = session.query(GetBook.book_id).order_by(GetBook.created_on.desc()).first()
#             book_id = str(book_result[0])
#             return{
#                 "Message": "Book created successfully",
#                 "book_id": book_id
#             }
#     except TypeError as error :
#         session.rollback()
#         api_exception_obj = {
#             "error" : "Invalid request",
#             "errorMessage" : "Missing / Wrong details"+str(error_columns)
#         }
#         api_exception_json = json.dumps(api_exception_obj)
#         raise Error(api_exception_json)
#     except ValueError as error :
#         session.rollback()
#         if(no_need==False):
#             api_exception_obj = {
#             "error" : "Invalid request",
#             "errorMessage" : "Extra Parameters Passed , Parameters not required"
#         }
#         else:
#             api_exception_obj = {
#             "error" : "Invalid request",
#             "errorMessage" : "Missing / Wrong details"
#         }
#         api_exception_json = json.dumps(api_exception_obj)
#         raise Error(api_exception_json)  
#     except exc.SQLAlchemyError as error:
#         session.rollback()
#         error_text = "An SQLAlchemy error occurred in Resource microservice, Validation error"
#         api_exception_obj = {
#             "type" : "Invalid request",
#             "message" : error_text
#         }
#         api_exception_json = json.dumps(api_exception_obj)
#         raise Error(api_exception_json)
#     except Exception as error:
#         session.rollback()
#         exc_type, exc_obj, exc_tb = sys.exc_info()
#         api_exception_obj = {
#             "error" : "Internal server error",
#             "errorMessage" :str(error) + " Line number: " + str(exc_tb.tb_lineno)
#         }
#         api_exception_json = json.dumps(api_exception_obj)
#         raise Error(api_exception_json)
#     finally:
#         session.close()
def lambda_handler(event, context):
    return event












