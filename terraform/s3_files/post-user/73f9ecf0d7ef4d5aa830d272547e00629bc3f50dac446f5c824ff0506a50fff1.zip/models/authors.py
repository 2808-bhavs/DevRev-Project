from sqlalchemy import Column, VARCHAR, Integer, Text, DateTime
from models.base_model import BaseModel
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import UUID,FLOAT,JSONB
import uuid
from models.mapping_templates import AuthorMapping

class Authors(BaseModel):
    __tablename__="authors"

    author_id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,nullable = False)
    address_id = Column(UUID(as_uuid=True),default=uuid.uuid4,nullable = False)
    author_name = Column(Text(200),nullable = False)
    author_age = Column(Integer,nullable = False)
    author_rating = Column(FLOAT(3),nullable = False)
    qualification = Column(JSONB,nullable = False)
    specialist = Column(JSONB,nullable = False)
    status = Column(VARCHAR(1),nullable = False)
    created_by = Column(VARCHAR(120),nullable = False)
    created_on = Column(DateTime(timezone=True), server_default=func.now(), nullable = False)
    updated_by = Column(VARCHAR(120),nullable = False)
    updated_on = Column(DateTime(timezone=True), onupdate=func.now(), server_onupdate=func.now(), nullable = False)
    
    def author_request(self, data):
          try:
               mapping = AuthorMapping()
               for key, value in data.items():
                    if key in mapping.AUTHOR_MAPPING_TEMPLATE:
                         key_name = mapping.AUTHOR_MAPPING_TEMPLATE[key]
                         setattr(self, key_name, value)
          except Exception as e:
               print(e)
    