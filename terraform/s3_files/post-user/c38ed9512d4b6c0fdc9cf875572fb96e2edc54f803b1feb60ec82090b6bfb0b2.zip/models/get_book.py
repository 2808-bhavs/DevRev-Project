import sys
from sqlalchemy import Column, String, ForeignKey,DATE
from models.base_model import BaseModel
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import UUID,JSONB
import uuid
from models.mapping_templates import GetBookMapping
from models.authors import Authors
from models.category import Category

class GetBook(BaseModel):
    __tablename__ = "books"
    book_id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,nullable=False)
    book_name = Column(String(length=60), nullable = False)
    date_of_publication = Column(DATE, nullable=False)
    publisher_name = Column(String(length=200), nullable = False)
    author_id= Column(UUID(as_uuid=True),ForeignKey(Authors.author_id),nullable = False)
    category_id= Column(UUID(as_uuid=True),ForeignKey(Category.category_id),nullable = False)
    status= Column(String(length=1), nullable = False)
    other_details = Column(JSONB, nullable=True)
    created_by = Column(String(length=120), nullable = False)
    created_on = Column(DATE, server_default=func.now(), nullable=False)
    modified_by = Column(String(length=120), nullable = False)
    modified_on = Column(DATE, server_default=func.now(),onupdate=func.now(), nullable=False)  

    def out_payload_get_book(self):
        try:
            response = {

                "bookId": str(self.book_id),
                "bookName": str(self.book_name),
                "dateOfPublication": str(self.date_of_publication),
                "publisherName": str(self.publisher_name),
                "authorId": str(self.author_id),
                "categoryId": str(self.category_id),
                "status": str(self.status),
                "otherDetails":str(self.other_details),
                "createdBy":str(self.created_by),
                "createdOn": str(self.created_on),
                "modifiedBy": str(self.modified_by),
                "modifiedOn": str(self.modified_on)
            }
        except Exception as e :
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_tb.tb_lineno)
        return response
    def get_book_request(self, data):
        try:
            mapping = GetBookMapping()
            for key, value in data.items():
                if key in mapping.GET_BOOK_MAPPING_TEMPLATE:
                    book_key = mapping.GET_BOOK_MAPPING_TEMPLATE[key]
                    setattr(self, book_key, value)
        except Exception as e:
            print(str(e))