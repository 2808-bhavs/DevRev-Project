from sqlalchemy import DateTime,VARCHAR,Column, Boolean
from models.base_model import BaseModel

class Error(Exception):
    pass

class Login(BaseModel):
    __tablename__ = "login"
    email = Column(VARCHAR(30), primary_key=True, nullable = False)
    password = Column(VARCHAR(40),nullable = False)
    is_admin = Column(Boolean,nullable = False)
     