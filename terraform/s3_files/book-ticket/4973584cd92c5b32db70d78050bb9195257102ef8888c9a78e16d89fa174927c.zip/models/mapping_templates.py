class CategoryMapping:
    category_mapping_template = {
        "categoryId" : "category_id",
        "categoryName" : "category_name",
        "description" : "description",
        "status" : "status",
        "createdBy" : "created_by",
        "updatedBy" : "modified_by"
    }

#class for addressmapping
class AddressMapping:
    ADDRESS_MAPPING_TEMPLATE = {
        "addressId":"address_id",
        "doorNo": "door_no",
        "addressLine1":"address_line_1",
        "addressLine2": "address_line_2",
        "place": "place",
        "city": "city",
        "zipcode": "zipcode",
        "latitude":"latitude",
        "longitude":"longitude",
        "countryCode":"country_uuid",
        "otherDetails":"other_details",
        "createdBy":"created_by",
        "updatedBy":"updated_by"
    }

#class for libraryMapping
class LibraryMapping:
    LIBRARY_MAPPING_TEMPLATE = {
        "addressId": "address_id",
        "libraryId": "library_id",
        "libraryName": "library_name",
        "libraryAge": "library_age",
        "specialization":"specialization",
        "status": "status",
        "otherDetails":'other_details',
        "createdBy": "created_by",
        "updatedBy":"updated_by"
    }

#class for mapping
class AuthorMapping:
     AUTHOR_MAPPING_TEMPLATE = {
          "authorId":"author_id",
          "addressId": "address_id",
          "authorName":"author_name",
          "authorAge": "author_age",
          "authorRating": "author_rating",
          "qualification": "qualification",
          "specialist": "specialist",
          "status": "status",
          "createdBy":"created_by",
          "updatedBy":"updated_by"
     }

#class for get flight mapping
class GetFligthMapping:
    GET_FLIGHT_MAPPING_TEMPLATE = {
        
        "journeyId": "journey_id",
        "flightNumber": "flight_num",
        "flightName": "flight_name",
        "dateOfJourney": "date",
        "From": "journey_from",
        "To": "journey_to",
        "departureTime": "departure_time",
        "arrivalTime": "arrival_time"

    }

#class for get book stock mapping
class GetBookingMapping:
    GET_BOOKING_MAPPING_TEMPLATE = {
        
        "bookingId": "booking_id",
        "journeyId": "journey_id"

    }

class AddUser:
    ADD_USER_TEMPLATE = {
        "email": "email",
        "password": "password",
        "is_admin": "is_admin"
    }