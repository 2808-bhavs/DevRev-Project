import re

class Validations:
    """
    This class is used to validate the mandatory fields in the body
    """
    def validation(category_name,description,status,created_by):
        """
        Arguments:
            category_name(string) : It should contain only alphabets and maximum length is 120
            description(string) : Maximum length is 400
            status(string) : It should contain only alphabets and maximum length is 1
            created_by(string) : It should contain only alphabets and maximum length is 120 

        Returns: List which contains the column-names of the errors
        """
        error_list = []
        if not(category_name.strip()) or len(category_name)>120 or (re.match('[@_!#$%^&*()<>?/\|}{~:]',category_name)) or not(re.match('[a-zA-Z\s]+$',category_name)):
            error_list.append('categoryName')

        if not(description.strip()) or len(description)>400 or (re.match('[@_!#$%^&*()<>?/\|}{~:]',description)) or not(re.match('[a-zA-Z\s]+$',description)):
            error_list.append('description')

        if not(status.strip()) or len(status)>1 or (re.match('[@_!#$%^&*()<>?/\|}{~:]',status)) or not(re.match('[a-zA-Z\s]+$',status)):
            error_list.append('status')
            
        if not(created_by.strip()) or len(created_by)>120 or (re.match('[@_!#$%^&*()<>?/\|}{~:]',created_by)) or not(re.match('[a-zA-Z\s]+$',created_by)):
            error_list.append('createdBy/updatedBy')

        return error_list


class Validate:
    """"
        validation method validates the each variable in author data and raise exception if there was any error.
    """
    def validation(data):
        error_list=[]
        if not data:
            error_list.append('body-json')
        if('authorName' not in data or data['authorName'] == None or not(data['authorName'].strip()) or not(re.match('[a-zA-Z\s]+$',data['authorName'])) or len(data['authorName'])>200):
            error_list.append('author_name')
        if('authorAge' not in data or data['authorAge'] == None or not(re.match('^[0-9]+$',str(data['authorAge']))) or len(str(data['authorAge']))>3):
            error_list.append('author_age')
        if('authorRating' not in data or data['authorRating'] == None or not(re.match('^[0-9.]+$',str(data['authorRating']))) or len(str(data['authorRating']))>5):
            error_list.append('author_rating')
        if('qualification' not in data or data['qualification'] == None):
            error_list.append('qualification')
        if('specialist' not in data or data['specialist'] == None):
            error_list.append('specialist')
        if('status' not in data or data['status'] == None or not(data['status'].strip()) or not(re.match('^[APD]+$',str(data['status']))) or len(data['status'])>1):
            error_list.append('status')

        return error_list
         