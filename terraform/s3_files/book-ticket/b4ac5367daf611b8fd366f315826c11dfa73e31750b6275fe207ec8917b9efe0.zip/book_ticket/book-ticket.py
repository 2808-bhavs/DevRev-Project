

def lambda_handler(event, context):
    return event
    # try:
    #     request_body = event["body-json"]
    #     missing_fields = post_library_body_validation(event)
    #     if missing_fields:
    #         raise ValueError()
    #     else:
    #         connection = DB()
    #         Session = connection.connect()
    #         session = Session()
    #         libraryId = uuid4()
    #         request_body['updatedBy'] = request_body['createdBy']
    #         request_body['libraryId'] = str(libraryId)
    #         library_details = library()
    #         library_details.library_request(request_body)
    #         session.add(library_details)
    #         session.commit()
    #         return {
    #             "Message": "library created successfully",
    #             "libraryId": request_body['libraryId']
    #         }
    # except ValueError:
    #     api_exception_obj = {
    #         "error": "Invalid request",
    #         "errorMessage": "Missing / Wrong details entered in column "+str(missing_fields)
    #     }
    #     api_exception_json = json.dumps(api_exception_obj)
    #     raise Error(api_exception_json)

    # except IntegrityError as e:
    #     assert isinstance(e.orig, ForeignKeyViolation)
    #     api_exception_obj = {
    #         "error": "Internal server error",
    #         "errorMessage": "addressId foreign key violation"
    #     }
    #     api_exception_json = json.dumps(api_exception_obj)
    #     raise Error(api_exception_json)

    # except Exception as e:
    #     print(e)
    #     api_exception_obj = {
    #         "error": "Internal server error",
    #         "errorMessage": str(e)
    #     }
    #     api_exception_json = json.dumps(api_exception_obj)
    #     raise Error(api_exception_json)
