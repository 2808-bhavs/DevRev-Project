class Error(Exception):
    pass