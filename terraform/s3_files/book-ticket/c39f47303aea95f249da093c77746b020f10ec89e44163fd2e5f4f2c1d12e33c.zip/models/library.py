from sqlalchemy import Column, String, TIMESTAMP, ForeignKey
from models.base_model import BaseModel
from models.address import address
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import UUID,JSONB
import uuid
from models.mapping_templates import LibraryMapping

class library(BaseModel):
    __tablename__ = "library"
    library_id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,nullable=False)
    address_id = Column(UUID(as_uuid=True),ForeignKey(address.address_id),nullable = False)
    library_name = Column(String(length=60), nullable = False)
    library_age = Column(String(length=3), nullable = False)
    specialization = Column(String(length=30), nullable = False)
    status = Column(String(length=1), nullable = False)
    other_details = Column(JSONB, nullable=False)
    created_by = Column(String(length=120), nullable = False)
    created_on = Column(TIMESTAMP(timezone=False), server_default=func.now(), nullable=True)
    updated_by = Column(String(length=120), nullable = True)
    updated_on = Column(TIMESTAMP(timezone=False), server_default=func.now(), nullable=True,onupdate=func.now())      
      
    def library_request(self, data):
        try:
            mapping = LibraryMapping()
            for key, value in data.items():
                if key in mapping.LIBRARY_MAPPING_TEMPLATE:
                    b_key = mapping.LIBRARY_MAPPING_TEMPLATE[key]
                    setattr(self, b_key, value)
        except Exception as e:
            print(str(e))