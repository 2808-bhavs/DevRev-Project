import json
from uuid import UUID
from service.DBInit import DB
from models.address import address
from models.country import country
from sqlalchemy.orm.exc import NoResultFound
from service.custom_exception import Error

"""
 # @Python program 
 # @Author: T Hemanth Kumar
 # @Name: main.py
 # @Lambda name: lms_address_lambda
 # @Version: 1.0
 # @See: Program to get address information using adress_id
"""
""" 
    Title:
        Lambda Handler method to get address information from the database using adress_id
"""
def lambda_handler(event,context):
    try:
        address_id = event['params']['querystring']['addressId']
        connection = DB()
        Session = connection.connect()
        session = Session()
        UUID(address_id)
        address_data = session.query(address,country) \
            .join(country, country.country_uuid == address.country_uuid) \
            .filter(address.address_id == address_id).all()
        
        responses = [
                {
                    "addressId": str(data[0].address_id),
                    "doorNo": data[0].door_no,
                    "addressLine1 ": data[0].address_line_1,
                    "addressLine2 " : data[0].address_line_2,
                    "place": data[0].place,
                    "city": data[0].city,
                    "zipcode": data[0].zipcode,
                    "latitude ": data[0].latitude,
                    "longtiude ": data[0].longitude,
                    "countryCodeUuid ": str(data[0].country_uuid),
                    "CountryCode": str(data[1].country_code),
                    "CountryName ": data[1].country_name,
                    "otherDetails" : data[0].other_details,
                    "CreatedBy ": data[0].created_by,
                    "createdon": str(data[0].created_on),
                    "updatedBy": data[0].updated_by,
                    "updatedon": str(data[0].updated_on)
                }
                for data in address_data
        ]
        if not responses:
            raise NoResultFound()
        else:    
            return responses[0]
    
    except NoResultFound:
        api_exception_obj = {
            "error" : "Address not found",
		}
        api_exception_json = json.dumps(api_exception_obj)
        raise Error(api_exception_json)

    except ValueError:
        api_exception_obj = {
            "error" : "Invalid request",
            "errorMessage" : "Missing / Wrong details entered in [addressId]"
		}
        api_exception_json = json.dumps(api_exception_obj)
        raise Error(api_exception_json)

    except Exception:
        api_exception_obj = {
            "error" : "Internal server error",
            "errorMessage" : "Wrong details"
		}
        api_exception_json = json.dumps(api_exception_obj)
        raise Error(api_exception_json)
    finally:
        session.close()	
    