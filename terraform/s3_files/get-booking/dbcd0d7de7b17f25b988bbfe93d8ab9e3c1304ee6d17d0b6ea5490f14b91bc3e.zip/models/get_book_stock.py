import sys
from sqlalchemy import Column,Integer, ForeignKey
from models.base_model import BaseModel
from sqlalchemy.dialects.postgresql import UUID
from models.mapping_templates import GetBookStockMapping
from models.get_book import GetBook
from models.library import library
class GetBookStock(BaseModel):
    __tablename__ = "books_at_library"
    book_id = Column(UUID(as_uuid=True),ForeignKey(GetBook.book_id),primary_key = True,nullable=False)
    library_id = Column(UUID(as_uuid=True),ForeignKey(library.library_id),primary_key=True,nullable=False) 
    stock_in_hands = Column(Integer,nullable=False) 
    def out_payload_get_book(self):
        try:
            response = {
                "bookId": str(self.book_id),
                "libraryId": str(self.library_id),
                "stockInHands": str(self.stock_in_hands)
            }
        except Exception as e :
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_tb.tb_lineno)
        return response
    def get_book_stock_request(self, data):
        try:
            mapping = GetBookStockMapping()
            for key, value in data.items():
                if key in mapping.GET_BOOK_STOCK_MAPPING_TEMPLATE:
                    b_key = mapping.GET_BOOK_STOCK_MAPPING_TEMPLATE[key]
                    setattr(self, b_key, value)
        except Exception as e:
            print(str(e))