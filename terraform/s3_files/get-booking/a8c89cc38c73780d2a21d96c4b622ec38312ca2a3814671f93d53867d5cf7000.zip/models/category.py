from sqlalchemy import DateTime,VARCHAR,Column
from sqlalchemy.dialects.postgresql import UUID
import uuid
from sqlalchemy.sql import func
from models.base_model import BaseModel
from models.mapping_templates import CategoryMapping

class Error(Exception):
    pass

class Category(BaseModel):
    __tablename__ = "category"
    category_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4,nullable = False)
    category_name = Column(VARCHAR(120),nullable = False)
    description = Column(VARCHAR(400),nullable = False)
    status = Column(VARCHAR(1),nullable = False)
    created_by = Column(VARCHAR(120),nullable = False)
    created_on = Column(DateTime(timezone=True), server_default=func.now())
    modified_by = Column(VARCHAR(120),nullable = False)
    modified_on = Column(DateTime(timezone=True), server_default=func.now(),onupdate=func.now())

    def get_category(self):
    
        response = {
            "categoryId": str(self.category_id),
            "categoryName": str(self.category_name),
            "description" : str(self.description),
            "status":str(self.status),
            "createdBy":str(self.created_by),
            "createdOn":str(self.created_on),
            "modifiedBy":str(self.modified_by),
            "modifiedOn":str(self.modified_on)
        }
        return response

    def category(self,request_payload):
        mapping = CategoryMapping
        for key,value in request_payload.items():
            if key in mapping.category_mapping_template:
                cat = mapping.category_mapping_template[key]
                setattr(self,cat,value)        