from sqlalchemy import Column, String, TIMESTAMP, Integer, ForeignKey
from models.base_model import BaseModel
from sqlalchemy.sql import func
from sqlalchemy.dialects.postgresql import UUID,JSONB
import uuid
from models.mapping_templates import AddressMapping
from models.country import country

class address(BaseModel):
    __tablename__ = "address"
    address_id = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,nullable=False)
    door_no = Column(String(length=30), nullable = False)
    address_line_1 = Column(String(length=60), nullable = False)
    address_line_2 = Column(String(length=60), nullable = False)
    place = Column(String(length=30), nullable = False)
    city = Column(String(length=50), nullable = False)
    zipcode = Column(Integer, nullable = False)
    latitude = Column(String(length=30), nullable = False)
    longitude = Column(String(length=30), nullable = False)
    country_uuid = Column(UUID(as_uuid=True),ForeignKey(country.country_uuid),nullable = False)
    other_details = Column(JSONB, nullable=False)
    created_by = Column(String(length=120), nullable = False)
    created_on = Column(TIMESTAMP(timezone=False), server_default=func.now(), nullable=False)
    updated_by = Column(String(length=120), nullable = True)
    updated_on = Column(TIMESTAMP(timezone=False), server_default=func.now(), nullable=True,onupdate=func.now())  
        
    def address_request(self, data):
        try:
            mapping = AddressMapping()
            for key, value in data.items():
                if key in mapping.ADDRESS_MAPPING_TEMPLATE:
                    b_key = mapping.ADDRESS_MAPPING_TEMPLATE[key]
                    setattr(self, b_key, value)
        except Exception as e:
            print(str(e))