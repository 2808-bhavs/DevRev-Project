from sqlalchemy import Column, String
from models.base_model import BaseModel
from sqlalchemy.dialects.postgresql import UUID
import uuid
class country(BaseModel):
    __tablename__ = "country"
    country_uuid = Column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4,nullable=False)
    country_name = Column(String(length=60), nullable = False)
    country_code = Column(String(length=2), nullable = False)
